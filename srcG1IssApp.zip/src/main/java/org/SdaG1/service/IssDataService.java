package org.SdaG1.service;

import org.SdaG1.model.IssPositionData;

public class IssDataService implements IssDataServiceInterface{


    @Override
    public double calculateSpeed() {
        return 0;
    }

    @Override
    public IssPositionData showCurrentIssLocation() {
        return null;
    }

    @Override
    public void save() {

    }
}
